//
//  BetteryIndicator.swift
//  CustomBetteryDemo
//
//  Created by PC on 20/03/23.
//

import UIKit

class BetteryIndicator: UIView {
    
    @IBOutlet var contantView: UIView!
    
    var mainShapeLayer: CAShapeLayer = CAShapeLayer()
    var insideShapeLayer: CAShapeLayer = CAShapeLayer()
    var betteryShapeLayer: CAShapeLayer = CAShapeLayer()
    var maskShapeLayer: CAShapeLayer = CAShapeLayer()
    var labelShapeLayer: CAShapeLayer = CAShapeLayer()
    
    var label: UILabel = UILabel()
    
    // setBetteryPercentage
    var betteryPercentagelevel: CGFloat = 1
    {
        didSet
        {
            betteryShapeLayer.strokeEnd = betteryPercentagelevel
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    // setupView
    func setupView() {
        Bundle.main.loadNibNamed("BetteryIndicator", owner: self, options: nil)
        addSubview(contantView)
        contantView.frame = self.bounds
        contantView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        
        setupMainBodyLayer()
        setupBetteryLevelLayer()
        setupMaskLayer()
        setupInsideBodyLayer()
        setupBetteryPercentageLabel(mainShapeLayer: mainShapeLayer)
    }
    
    // MARK: - setupMainBodyLayer
    // setupMainBodyLayer
    func setupMainBodyLayer() {
        
        mainShapeLayer.fillColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1).cgColor
        
        mainShapeLayer.strokeColor = UIColor.clear.cgColor
        mainShapeLayer.lineWidth = 1.5
        self.layer.addSublayer(mainShapeLayer)
        mainShapeLayer.path = createBezierPathForMainBodyLayer().cgPath
        
    }
    
    // createBezierPathForMainBodyLayer
    func createBezierPathForMainBodyLayer() -> UIBezierPath {
        let path: UIBezierPath = UIBezierPath()
        
        // center point of Y-axis
        let centerY = self.frame.size.height / 2
        _ = self.frame.size.width / 2
        
        // starting point for the path (bottom left)
        path.move(to: CGPoint(x: 0, y: centerY + reSizeHeight(30))) //y: 30
        
        // segment 1: line
        path.addLine(to: CGPoint(x: 0, y: centerY - reSizeHeight(30))) //y: 30
        
        // segment 2: arc (Top left corner)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(20), y: centerY - reSizeHeight(30)), //x: 20 //y: 30
                    radius: reSizeWidth(20), //x: 20
                    startAngle: CGFloat(Double.pi),
                    endAngle: CGFloat(3 * Double.pi / 2),
                    clockwise: true)
        
        // segment 3: line
        path.addLine(to: CGPoint(x: reSizeWidth(145), y: 0)) //x: 145
        
        // segment 4: arc (Top right corner)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(145), y: centerY - reSizeHeight(30)), //x: 145 //y: 30
                    radius: reSizeWidth(20), //x: 20
                    startAngle: CGFloat(3 * Double.pi / 2),
                    endAngle: CGFloat(0),
                    clockwise: true)
        print(self.frame.size.width - reSizeWidth(165))
        // segment 5: line
        path.addLine(to: CGPoint(x: reSizeWidth(185), y: centerY - reSizeHeight(30))) //x: 185 //y: 30
        
        // segment 6: arc (Bettery Handler Top)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(185), y: centerY - reSizeHeight(15)), //x: 185 //y: 15
                    radius: reSizeWidth(15), //x: 15
                    startAngle: CGFloat(3 * Double.pi / 2),
                    endAngle: CGFloat(0),
                    clockwise: true)
        
        // segment 7: arc (Bettery Handler Bottom)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(185), y: centerY + reSizeHeight(15)), //x: 185 //y: 15
                    radius: reSizeWidth(15), //x: 15
                    startAngle: CGFloat(Double.pi * 2),
                    endAngle: CGFloat(-(3 * Double.pi / 2)),
                    clockwise: true)
        
        // segment 8: line
        path.addLine(to: CGPoint(x: reSizeWidth(165), y: centerY + reSizeHeight(30))) //x: 165 //y: 30
        
        // segment 9: arc (bottom right corner)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(145), y: centerY + reSizeHeight(30)), //x: 145 //y: 30
                    radius: reSizeWidth(20), //x: 20
                    startAngle: CGFloat(Double.pi * 2),
                    endAngle: CGFloat(-(3 * Double.pi / 2)),
                    clockwise: true)
        
        // segment 10: line
        path.addLine(to: CGPoint(x: reSizeWidth(20), y: centerY + reSizeHeight(50))) //x: 20 //y: 50
        
        // segment 11: arc (bottom left corner)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(20), y: centerY + reSizeHeight(30)), //x: 20 //y: 30
                    radius: reSizeWidth(20), //x: 20
                    startAngle: CGFloat(Double.pi / 2),
                    endAngle: CGFloat(Double.pi),
                    clockwise: true)
        
        
        path.close()
        return path
    }
    
    // reSizeWidth
    func reSizeWidth(_ widthValue: CGFloat) -> CGFloat {
        let width = self.frame.size.width
        return (width * widthValue) / 200
    }
    
    // reSizeHeight
    func reSizeHeight(_ heightValue: CGFloat) -> CGFloat {
        let height = self.frame.size.height
        return (height * heightValue) / 100
    }
    
    // MARK: - setupInsideBodyLayer
    // setupInsideBodyLayer
    func setupInsideBodyLayer() {
        
        insideShapeLayer.fillColor = UIColor.white.cgColor
        insideShapeLayer.strokeColor = UIColor.clear.cgColor
        insideShapeLayer.lineWidth = 1.5
        self.layer.addSublayer(insideShapeLayer)
        insideShapeLayer.path = createBezierPathForInsideBodyLayer().cgPath
    }
    
    // createBezierPathForInsideBodyLayer
    func createBezierPathForInsideBodyLayer() -> UIBezierPath {
        
        let path: UIBezierPath = UIBezierPath()
        
        // center point of Y-axis
        let centerY = self.frame.size.height / 2
        
        // starting point of path top left
        path.move(to: CGPoint(x: reSizeWidth(165), y: centerY - reSizeHeight(15))) //x: 165 //y: 15 // change 15 if width is more
        
        // segment 1: line
        path.addLine(to: CGPoint(x: reSizeWidth(180), y: centerY - reSizeHeight(15))) //x: 180 //y: 15 // change 15 if width is more
        
        // segment 2: arc (Top right side)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(177.5), y: centerY - reSizeHeight(5)), //x: 177.5 //y: 5
                    radius: reSizeWidth(10), //x: 10
                    startAngle: CGFloat(3 * Double.pi / 2),
                    endAngle: CGFloat(0),
                    clockwise: true)
        
        // segment 3: line
        path.addLine(to: CGPoint(x: reSizeWidth(187.5), y: centerY + reSizeHeight(0))) //x: 187.5 //y: 10
        
        // segment 2: arc (Buttom rightside)
        path.addArc(withCenter: CGPoint(x: reSizeWidth(177.5), y: centerY + reSizeHeight(5)), //x: 177.5 //y: 5
                    radius: reSizeWidth(10), //x: 10
                    startAngle: CGFloat(Double.pi * 2),
                    endAngle: CGFloat(-(3 * Double.pi / 2)),
                    clockwise: true)
        
        // segment 3: line
        path.addLine(to: CGPoint(x: reSizeWidth(165), y: centerY + reSizeHeight(15))) //x: 165 //y: 15 // change 15 if width is more
        
        path.close()
        return path
    }
    
    // setupBetteryPercentageLabel (Label)
    func setupBetteryPercentageLabel(mainShapeLayer: CAShapeLayer) {
        
        let batteyMainWidth = reSizeWidth(165)
        //MARK: - UILabel Setup
        label = UILabel(frame: CGRect(x: 0,
                                      y: 0,
                                      width: reSizeWidth(120),
                                      height: reSizeHeight(50)))
        label.center = CGPoint(x: batteyMainWidth / 2, y: self.bounds.midY)
        label.font = label.font.withSize(14)
        label.textAlignment = .center
        
        mainShapeLayer.contents = label
        betteryShapeLayer.addSublayer(label.layer)
    }
    
    // MARK: - setupBetteryLevelLayer
    // setupBetteryLevelLayer
    func setupBetteryLevelLayer() {
        
        let centerY = self.frame.size.height / 2
        let width = self.frame.size.width
        let animationPath: UIBezierPath = UIBezierPath()
        
        
        layer.addSublayer(betteryShapeLayer)
        animationPath.move(to: CGPoint(x: 0, y: centerY))
        animationPath.addLine(to: CGPoint(x: width, y: centerY))
        
        betteryShapeLayer.path = animationPath.cgPath
        betteryShapeLayer.strokeColor = UIColor(red: 79/255, green: 227/255, blue: 216/255, alpha: 1).cgColor
        betteryShapeLayer.lineWidth = bounds.width
        betteryShapeLayer.strokeEnd = betteryPercentagelevel // Set Animation Percentage
        
    }
    
    // MARK: - setupMaskLayer
    func setupMaskLayer() {
        maskShapeLayer.path = mainShapeLayer.path
        betteryShapeLayer.mask = maskShapeLayer
        maskShapeLayer.frame = mainShapeLayer.frame
    }
    
}

// MARK: - OLD
//class BetteryIndicator: UIView {
//
//    @IBOutlet var contantView: UIView!
//
//    var shapeLayer: CAShapeLayer = CAShapeLayer()
//
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        setupView()
//    }
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        setupView()
//    }
//
//    func setupView() {
//        Bundle.main.loadNibNamed("BetteryIndicator", owner: self, options: nil)
//        addSubview(contantView)
//        contantView.frame = self.bounds
//        contantView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
//
//        setupMainBodyLayer()
//    }
//
//    func setupMainBodyLayer() {
//
//        shapeLayer.fillColor = UIColor.systemGray.cgColor
//        shapeLayer.strokeColor = UIColor.black.cgColor
//        shapeLayer.lineWidth = 1.5
//        self.layer.addSublayer(shapeLayer)
//        shapeLayer.path = createBezierPath().cgPath
//    }
//
//    func createBezierPath() -> UIBezierPath {
//        let path: UIBezierPath = UIBezierPath()
//
//        let centerY = self.frame.size.height / 2
//
//        // starting point for the path (bottom left)
//        path.move(to: CGPoint(x: 0, y: centerY + 30))
//
//        // segment 1: line
//        path.addLine(to: CGPoint(x: 0, y: centerY - 30))
//
//        // segment 2: arc (Top left corner)
//        path.addArc(withCenter: CGPoint(x: 30, y: centerY - 20),
//                    radius: 30,
//                    startAngle: CGFloat(Double.pi),
//                    endAngle: CGFloat(3 * Double.pi / 2),
//                    clockwise: true)
//
//        // segment 3: line
//        path.addLine(to: CGPoint(x: 130, y: 0))
//
//        // segment 2: arc (Top right corner)
//        path.addArc(withCenter: CGPoint(x: 130, y: centerY - 20),
//                    radius: 30,
//                    startAngle: CGFloat(3 * Double.pi / 2),
//                    endAngle: CGFloat(0),
//                    clockwise: true)
//
//        // segment 4: line
//        path.addLine(to: CGPoint(x: 180, y: centerY - 20))
//
//        // segment 5: arc (Bettery Handler Top)
//        path.addArc(withCenter: CGPoint(x: 180, y: centerY),
//                    radius: 20,
//                    startAngle: CGFloat(3 * Double.pi / 2),
//                    endAngle: CGFloat(0),
//                    clockwise: true)
//
//        // segment 6: arc (Bettery Handler Bottom)
//        path.addArc(withCenter: CGPoint(x: 180, y: centerY),
//                    radius: 20,
//                    startAngle: CGFloat(Double.pi * 2),
//                    endAngle: CGFloat(-(3 * Double.pi / 2)),
//                    clockwise: true)
//
//        // segment 7: line
//        path.addLine(to: CGPoint(x: 160, y: centerY + 20))
//
//        // segment 8: arc (bottom right corner)
//        path.addArc(withCenter: CGPoint(x: 130, y: centerY + 20),
//                    radius: 30,
//                    startAngle: CGFloat(Double.pi * 2),
//                    endAngle: CGFloat(-(3 * Double.pi / 2)),
//                    clockwise: true)
//
//        // segment 9: line
//        path.addLine(to: CGPoint(x: 30, y: centerY + 50))
//
//         // segment 10: arc (bottom left corner)
//         path.addArc(withCenter: CGPoint(x: 30, y: centerY + 20),
//                     radius: 30,
//                     startAngle: CGFloat(Double.pi / 2),
//                     endAngle: CGFloat(Double.pi),
//                     clockwise: true)
//
////        path.addCurve(to: CGPoint(x: 0, y: centerY + 30),
////                      controlPoint1: CGPoint(x: 30, y: centerY + 20),
////                      controlPoint2: CGPoint(x: 0, y: centerY + 30))
//
//        path.close()
//
//        return path
//    }
//
//}

// MARK: - OLD
