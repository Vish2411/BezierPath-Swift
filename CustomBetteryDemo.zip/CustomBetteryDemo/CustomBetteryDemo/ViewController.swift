//
//  ViewController.swift
//  CustomBetteryDemo
//
//  Created by PC on 20/03/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var betteryIndicatorView: BetteryIndicator!
    
    var percentange: Float?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        betteryIndicatorView.betteryPercentagelevel = 0.7 // setBetteryLevelHere
        percentange = (Float(betteryIndicatorView.betteryPercentagelevel) * 100)
        betteryIndicatorView.label.text = "\(Int(percentange ?? 0))%"
    }

}

